[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH /home/hebkghti/public_html/ciitesonline.com/resources/views/vendor/mail/text/header.blade.php ENDPATH**/ ?>