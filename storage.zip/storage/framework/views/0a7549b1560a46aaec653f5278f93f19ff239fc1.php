<?php echo e($slot); ?>

<?php /**PATH /home/acinvest/app/resources/views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>