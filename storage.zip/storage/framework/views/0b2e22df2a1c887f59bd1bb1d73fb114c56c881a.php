<?php echo e($slot); ?>

<?php /**PATH /home/fxproglobaltradi/public_html/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>