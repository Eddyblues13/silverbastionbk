<?php echo e($slot); ?>

<?php /**PATH /home/prostableassets/public_html/fund/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>