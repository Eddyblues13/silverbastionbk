 <!-- Top Up Modal -->
 <div id="topupModal" class="modal fade" role="dialog">
     <div class="modal-dialog">
         <!-- Modal content-->
         <div class="modal-content">
             <div class="modal-header ">
                <img alt="" src="<?php echo e($settings->site_address); ?>/storage/app/public/photos/<?php echo e($user->profile_photo_path); ?>" width="60" height="60" style='border-radius: 50%;'> <h4 class="modal-title pl-1">Fund/Debit Account.</strong></h4>
                 <button type="button" class="close " data-dismiss="modal">&times;</button>
             </div>
             <div class="modal-body ">
                 <form method="post" action="<?php echo e(route('topup')); ?>">
                     <?php echo csrf_field(); ?>
                     <div class="form-group">
                        <h4 class="">Amount</h4>
                         <input class="form-control" placeholder="Enter amount" type="number" name="amount"
                             required>
                     </div>
                     <div class="form-group">
                         <h5 class="">Select where to Fund/Debit</h5>
                         <select class="form-control" name="type" required>
                
                             
                             <option value="balance">Account Balance</option>
                             
                             
                            
                             
                         </select>
                     </div>
                     <div class="form-group">
                         <h5 class="">Select Fund to add, debit to subtract.</h5>
                         <select class="form-control  " name="t_type" required>
                             <option value="">Select type</option>
                             <option value="Credit">Fund </option>
                             <option value="Debit">Debit</option>
                         </select>
                         
                     </div>
                     <div class="form-group">
                        <h5 class="">Transfer Scope.</h5>
                        <select class="form-control  " name="scope" required>
                            <option value="">Select type</option>
                            <option value="International transfer">International transfer</option>
                            <option value="Local transfer">Local transfer</option>
                            <option value="Crypto Deposit">Crypto Deposit</option>
                            <option value="Check Deposit">Check Deposit</option>
                        </select>
                        
                    </div>
                     <div class="form-group">
                        <h5 class="">Description </h5>
                        <input class="form-control" name="Description" type='text' >
                            
                        
                    </div>
                     <div class="form-group">
                        <h5 class="">Date (You can back date transction here)</h5>
                        <input class="form-control" name="date" type='date' >
                            
                        
                    </div>
                     <div class="form-group">
                         <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">
                         <input type="submit" class="btn btn-primary" value="Fund Account">
                     </div>
                 </form>
             </div>
         </div>
     </div>
 </div>
 <!-- /deposit for a plan Modal -->
<!--user action mode-->
<div id="userAction" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header bg-<?php echo e($bg); ?>">
                    <h4 class="modal-title text-<?php echo e($text); ?>">Action amount  for<?php echo e($user->name); ?> account.</strong></h4>
                    <button type="button" class="close text-<?php echo e($text); ?>" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body bg-<?php echo e($bg); ?>">
                    <form method="post" action="<?php echo e(route('action')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <h5 class="text-<?php echo e($text); ?>">On or Off Action</h5>
                            <select class="form-control bg-<?php echo e($bg); ?> text-<?php echo e($text); ?>" name="type" required>
                                <option value="" selected disabled>Select Column</option>
                                <option value="Yes">On upgrade action</option>
                                <option value="No">Off upgrade action</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <input class="form-control bg-<?php echo e($bg); ?> text-<?php echo e($text); ?>" placeholder="Enter actoin amount" type="text" name="amount">
                        </div>
                        
                        <div class="form-group">
                            <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">
                            <input type="submit" class="btn btn-<?php echo e($text); ?>" value="Submit">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!--user action modal end-->
<!--signal action model-->


<div id="userActionsignal" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header bg-<?php echo e($bg); ?>">
                    <h4 class="modal-title text-<?php echo e($text); ?>">Signal action for <?php echo e($user->name); ?> account.</strong></h4>
                    <button type="button" class="close text-<?php echo e($text); ?>" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body bg-<?php echo e($bg); ?>">
                    <form method="post" action="<?php echo e(route('signalaction')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <h5 class="text-<?php echo e($text); ?>">On or Off signal action</h5>
                            <select class="form-control bg-<?php echo e($bg); ?> text-<?php echo e($text); ?>" name="signalstatus" required>
                                <option value="" selected disabled>Select Column</option>
                                <option value="Yes">On signal</option>
                                <option value="No">Off signal</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <input class="form-control bg-<?php echo e($bg); ?> text-<?php echo e($text); ?>" placeholder="Enter actoin amount" type="text" name="signalamount" >
                        </div>
                         <div class="form-group">
                            <input class="form-control bg-<?php echo e($bg); ?> text-<?php echo e($text); ?>" placeholder="Enter signal name" type="text" name="signalname" >
                        </div>
                        
                        <div class="form-group">
                            <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">
                            <input type="submit" class="btn btn-<?php echo e($text); ?>" value="Submit">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!--user action modal end-->

 <!-- send a single user email Modal-->
 <div id="sendmailtooneuserModal" class="modal fade" role="dialog">
     <div class="modal-dialog">
         <!-- Modal content-->
         <div class="modal-content">
             <div class="modal-header ">
                 <h4 class="modal-title ">Send Email</h4>
                 <button type="button" class="close " data-dismiss="modal">&times;</button>
             </div>
             <div class="modal-body ">
                 <p class="">This message will be sent to <?php echo e($user->name); ?></p>
                 <form style="padding:3px;" role="form" method="post" action="<?php echo e(route('sendmailtooneuser')); ?>">
                     <?php echo csrf_field(); ?>
                     <div class=" form-group">
                         <input type="text" name="subject" class="form-control  " placeholder="Subject" required>
                     </div>
                     <div class=" form-group">
                         <textarea placeholder="Type your message here" class="form-control  " name="message" row="8"
                             placeholder="Type your message here" required></textarea>
                     </div>
                     <div class=" form-group">
                         <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">
                         <input type="submit" class="btn " value="Send">
                     </div>
                 </form>
             </div>
         </div>
     </div>
 </div>
 <!-- /Trading History Modal -->

 <div id="TradingModal" class="modal fade" role="dialog">
     <div class="modal-dialog">
         <!-- Modal content-->
         <div class="modal-content">
             <div class="modal-header ">
                 <h4 class="modal-title ">  <img alt="" src="<?php echo e($settings->site_address); ?>/storage/app/public/photos/<?php echo e($user->profile_photo_path); ?>" width="60" height="60" style='border-radius: 50%;'><h1 class="d-inline text-primary"> <?php echo e($user->name); ?> <?php echo e($user->l_name); ?> </h4>
                 <button type="button" class="close " data-dismiss="modal">&times;</button>
             </div>
             <div class="modal-body ">
                 <form role="form" method="post" action="<?php echo e(route('profileimage')); ?>" enctype="multipart/form-data">
                     <?php echo csrf_field(); ?>
                     <div class="form-group">
                         <h5 class=" ">Change <?php echo e($user->name); ?> profile image</h5>
                         
                     </div>
                     <div class="form-group">
                         <h5 class=" ">Profile image</h5>
                         <input type="file" name="photo" class="form-control  ">
                     </div>
                     
                     <div class="form-group">
                         <input type="submit" class="btn btn-primary" value="Change Profile Image">
                         <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">
                     </div>
                 </form>
             </div>
         </div>
     </div>
 </div>
 <!-- /send a single user email Modal -->

 <!-- Edit user Modal -->
 <div id="edituser" class="modal fade" role="dialog">
     <div class="modal-dialog">
         <!-- Modal content-->
         <div class="modal-content">
             <div class="modal-header ">
                <img alt="" src="<?php echo e($settings->site_address); ?>/storage/app/public/photos/<?php echo e($user->profile_photo_path); ?>" width="60" height="60" style='border-radius: 50%;'> <h4 class="modal-title pl-1">Edit <?php echo e($user->name); ?> details.</strong></h4>
                 <button type="button" class="close " data-dismiss="modal">&times;</button>
             </div>
             <div class="modal-body ">
                 <form role="form" method="post" action="<?php echo e(route('edituser')); ?>">
                     <div class="form-group">
                         <h5 class=" ">Username</h5>
                         <input class="form-control  " id="input1" value="<?php echo e($user->username); ?>" type="text"
                             name="username" required>
                         <small>Note: same username should be use in the referral link.</small>
                     </div>
                     <div class="form-group">
                         <h5 class=" ">First Name</h5>
                         <input class="form-control  " value="<?php echo e($user->name); ?>" type="text" name="name"
                             required>
                     </div>
                     <div class="form-group">
                        <h5 class=" ">Middle Name</h5>
                        <input class="form-control  " value="<?php echo e($user->middlename); ?>" type="text" name="middlename"
                            required>
                    </div>

                    <div class="form-group">
                        <h5 class=" ">Last Name</h5>
                        <input class="form-control  " value="<?php echo e($user->lastname); ?>" type="text" name="lastname"
                            required>
                    </div>
                     <div class="form-group">
                         <h5 class=" ">Email</h5>
                         <input class="form-control  " value="<?php echo e($user->email); ?>" type="text" name="email"
                             required>
                     </div>
                     <div class="form-group">
                         <h5 class=" ">Phone Number</h5>
                         <input class="form-control  " value="<?php echo e($user->phone); ?>" type="text" name="phone"
                             required>
                     </div>
                     <div class="form-group">
                        <h5 class=" ">Account  Number</h5>
                        <input class="form-control  " value="<?php echo e($user->usernumber); ?>" type="text" name="usernumber"
                            required>
                    </div>
                    <div class="form-group">
                        <h5 class=" "><?php echo e($settings->code1); ?></h5>
                        <input class="form-control  " value="<?php echo e($user->code1); ?>" type="text" name="code1"
                            required>
                    </div>

                    <div class="form-group">
                        <h5 class=" "><?php echo e($settings->code2); ?></h5>
                        <input class="form-control  " value="<?php echo e($user->code2); ?>" type="text" name="code2"
                            required>
                    </div>
                    <div class="form-group">
                        <h5 class=" "><?php echo e($settings->code3); ?></h5>
                        <input class="form-control" value="<?php echo e($user->code3); ?>" type="text" name="code3"
                            required>
                    </div>
                    <div class="form-group col-md-12">
                        <h6 class="text-<?php echo e($text); ?>">Account Type</h6>
                        <select type="text" class="form-control  text-<?php echo e($text); ?>"
                            name="accounttype" value='<?php echo e($user->accounttype); ?>' required>
                            <option value="<?php echo e($user->accounttype); ?>"><?php echo e($user->accounttype); ?></option> 
                            <option value="Checking Account">Checking Account</option>
                            <option value="Savings Account">Saving Account</option>
                            <option value="Fixed Deposit Account">Fixed Deposit Account</option>
                            <option value="Current Account">Current Account</option>
                            <option value="Crypto Currency Account">Crypto Currency Account</option>
                            <option value="Business Account">Business Account</option>
                            <option value="Non Resident Account">Non Resident Account</option>
                            <option value="Cooperate Business Account">Cooperate Business Account</option>
                            <option value="Investment Account">Investment Account</option>
                    </select>
                    </div>
                    
                     <div class="form-group">
                        <h6 class="text-<?php echo e($text); ?>">Account Limit (<?php echo e($settings->currency); ?>) </h6>
                        <input type="number" class="form-control  text-<?php echo e($text); ?>"
                            name="limit" value='<?php echo e($user->limit); ?>' required>
                    </div>
                    <div class="form-group">
                        <h6 class="text-<?php echo e($text); ?>">4 Digit Transaction pin</h6>
                        <input type="text" class="form-control  text-<?php echo e($text); ?>"
                            name="pin" value='<?php echo e($user->pin); ?>' required>
                    </div>
                    
                     <div class="form-group">
                         <h5 class=" ">Country</h5>
                         <input class="form-control" value="<?php echo e($user->country); ?>" type="text" name="country">
                     </div>
                     
                     <div class="form-group">
                         <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                         <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">
                         <input type="submit" class="btn  btn-primary" value="Update">
                     </div>
                 </form>
             </div>
             <script>
                 $('#input1').on('keypress', function(e) {
                     return e.which !== 32;
                 });
             </script>
         </div>
     </div>
 </div>
 <!-- /Edit user Modal -->

 <!-- Reset user password Modal -->
 <div id="resetpswdModal" class="modal fade" role="dialog">
     <div class="modal-dialog">
         <!-- Modal content-->
         <div class="modal-content">
             <div class="modal-header ">
                 <h4 class="modal-title ">Reset Password</strong></h4>
                 <button type="button" class="close " data-dismiss="modal">&times;</button>
             </div>
             <div class="modal-body ">
                 <p class="">Are you sure you want to reset password for <?php echo e($user->name); ?> to <span
                         class="text-primary font-weight-bolder">user01236</span></p>
                 <a class="btn " href="<?php echo e(url('admin/dashboard/resetpswd')); ?>/<?php echo e($user->id); ?>">Reset Now</a>
             </div>
         </div>
     </div>
 </div>
 <!-- /Reset user password Modal -->

 <!-- Switch useraccount Modal -->
 <div id="switchuserModal" class="modal fade" role="dialog">
     <div class="modal-dialog">
         <!-- Modal content-->
         <div class="modal-content">
             <div class="modal-header ">
                 <h4 class="modal-title ">You are about to login as <?php echo e($user->name); ?>.</strong></h4>
                 <button type="button" class="close " data-dismiss="modal">&times;</button>
             </div>
             <div class="modal-body ">
                 <a class="btn btn-success"
                     href="<?php echo e(url('admin/dashboard/switchuser')); ?>/<?php echo e($user->id); ?>">Proceed</a>
             </div>
         </div>
     </div>
 </div>
 <!-- /Switch user account Modal -->

 <!-- Clear account Modal -->
 <div id="clearacctModal" class="modal fade" role="dialog">
     <div class="modal-dialog">
         <!-- Modal content-->
         <div class="modal-content">
             <div class="modal-header ">
                 <h4 class="modal-title ">Clear Account</strong></h4>
                 <button type="button" class="close " data-dismiss="modal">&times;</button>
             </div>
             <div class="modal-body ">
                 <p class="">You are clearing account for <?php echo e($user->name); ?> to <?php echo e($settings->currency); ?>0.00
                 </p>
                 <a class="btn " href="<?php echo e(url('admin/dashboard/clearacct')); ?>/<?php echo e($user->id); ?>">Proceed</a>
             </div>
         </div>
     </div>
 </div>
 <!-- /Clear account Modal -->

 <!-- Delete user Modal -->
 <div id="deleteModal" class="modal fade" role="dialog">
     <div class="modal-dialog">
         <!-- Modal content-->
         <div class="modal-content">
             <div class="modal-header ">

                 <h4 class="modal-title ">Delete User</strong></h4>
                 <button type="button" class="close " data-dismiss="modal">&times;</button>
             </div>
             <div class="modal-body  p-3">
                 <p class="">Are you sure you want to delete <?php echo e($user->name); ?> Account? Everything associated
                     with this account will be loss.</p>
                 <a class="btn btn-danger" href="<?php echo e(url('admin/dashboard/delsystemuser')); ?>/<?php echo e($user->id); ?>">Yes
                     i'm sure</a>
             </div>
         </div>
     </div>
 </div>
 <!-- /Delete user Modal -->
<?php /**PATH /home/u215313542/domains/remedycodes.site/public_html/resources/views/admin/Users/users_actions.blade.php ENDPATH**/ ?>