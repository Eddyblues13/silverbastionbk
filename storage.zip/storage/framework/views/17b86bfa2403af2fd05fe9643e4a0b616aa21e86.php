<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/remedycodes/public_html/fin.remedycodes.online/resources/views/vendor/mail/text/button.blade.php ENDPATH**/ ?>