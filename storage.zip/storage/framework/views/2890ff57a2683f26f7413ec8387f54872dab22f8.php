<?php echo e($slot); ?>

<?php /**PATH /home/internal/public_html/blissfxonlinetokenandinvestment.org/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>