[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH /Users/macbookair/Documents/Brynamics/OnlineTraderSoftware/onlinetrader/resources/views/vendor/mail/text/header.blade.php ENDPATH**/ ?>