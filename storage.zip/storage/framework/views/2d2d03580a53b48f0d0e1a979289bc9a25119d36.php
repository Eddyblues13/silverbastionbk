[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH /home/prostableassets/public_html/fund/resources/views/vendor/mail/text/header.blade.php ENDPATH**/ ?>