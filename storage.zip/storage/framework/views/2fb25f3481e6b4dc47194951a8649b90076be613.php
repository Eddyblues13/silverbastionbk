<?php echo e($slot); ?>

<?php /**PATH /home/remedycodes/public_html/fin.remedycodes.online/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>