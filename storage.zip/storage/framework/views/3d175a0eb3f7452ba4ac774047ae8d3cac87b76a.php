<hr>
DISCLAIMER: this message was automatically generated via <?php echo e($settings->site_name); ?> secured online channel, please do not reply this message. all correspondent should be address to customer Services.<br>
© <?php echo e(date('Y')); ?> <?php echo e(config('app.name')); ?>. <?php echo app('translator')->get('All rights reserved.'); ?><br>

<tr>
<td>
    
<table class="footer" align="center" width="570" cellpadding="0" cellspacing="0" role="presentation">
<tr>
<td class="content-cell" align="center">
  
<?php echo e($settings->address); ?>  
<?php echo e(Illuminate\Mail\Markdown::parse($slot)); ?>

</td>
</tr>
</table>
</td>
</tr>
<?php /**PATH /home/burlingm/grand.burlingmail.click/resources/views/vendor/mail/html/footer.blade.php ENDPATH**/ ?>