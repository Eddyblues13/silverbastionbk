<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/internal/public_html/westpayint.org/resources/views/vendor/mail/text/button.blade.php ENDPATH**/ ?>